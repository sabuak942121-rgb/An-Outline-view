"""Simple analysis of short-form video metrics.

Usage:
    python src/analyze_video_metrics.py examples/sample_metrics.json
"""

from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path
from typing import Any


def load_metrics(path: Path) -> list[dict[str, Any]]:
    """Load a list of episode metric records from JSON."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SystemExit(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Invalid JSON in {path}: {exc}") from exc

    if not isinstance(data, list) or not all(isinstance(item, dict) for item in data):
        raise SystemExit("Expected a JSON array of metric objects.")

    return data


def summarize(metrics: list[dict[str, Any]]) -> None:
    """Print useful summary statistics for retention experiments."""
    fields = ("hook_retention_3s", "completion_rate", "repeat_view_rate")
    values: dict[str, list[float]] = {field: [] for field in fields}

    for row in metrics:
        for field in fields:
            value = row.get(field)
            if isinstance(value, (int, float)):
                values[field].append(float(value))

    print(f"Episodes analysed: {len(metrics)}")
    print("-")
    for field, series in values.items():
        if not series:
            continue
        print(
            f"{field}: mean={statistics.mean(series):.1f}% "
            f"min={min(series):.1f}% max={max(series):.1f}%"
        )

    hook = values["hook_retention_3s"]
    completion = values["completion_rate"]
    if hook and completion:
        gap = statistics.mean(hook) - statistics.mean(completion)
        print("-")
        print(f"Average early-retention vs completion gap: {gap:.1f} percentage points")
        print(
            "Interpretation: getting a viewer to stop is a different problem "
            "from getting them to finish the story."
        )


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python src/analyze_video_metrics.py <metrics.json>")

    summarize(load_metrics(Path(sys.argv[1])))


if __name__ == "__main__":
    main()
