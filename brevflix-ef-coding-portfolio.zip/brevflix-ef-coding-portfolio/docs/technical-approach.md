# Technical approach

## The problem I care about

Brevflix experiments with very short serialized stories. The technical challenge is not simply generating video with AI; it is building a repeatable workflow that makes generation, evaluation, and iteration fast enough to learn from real viewers.

## How I work

1. Define the viewer behaviour we want to change.
2. Break the creative workflow into steps that can be tested independently.
3. Use AI tools to generate multiple alternatives quickly.
4. Measure the result with a small set of explicit metrics.
5. Compare what viewers actually did with what I expected.
6. Change one or two variables and run the experiment again.

## What I am learning

A strong first-second hook does not automatically create story completion. That is why I track early retention separately from completion and repeat viewing.

## Technical direction

As Brevflix grows, I want to move from tool-by-tool experimentation toward a more systematic production system: structured prompts, reusable evaluation schemas, asset management, experiment tracking, and eventually product infrastructure for the viewer experience.
