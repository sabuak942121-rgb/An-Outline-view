# Brevflix — Applied AI & Technical Experiments

A small technical portfolio documenting how I approach product problems with AI, automation, experimentation, and data.

## What this repository demonstrates

- Applied AI experimentation for short-form storytelling workflows
- Prompt iteration and structured evaluation
- Simple Python-based analysis of content metrics
- Product thinking: turning an idea into a measurable experiment
- A bias toward rapid testing before building a large platform

## About the founder

I am a product-focused founder building Brevflix, an AI-native microdrama company. My technical strength is applied problem solving: understanding what a product needs to do, testing AI tools quickly, designing workflows, and turning observations into experiments.

I am not presenting myself as a traditional software engineer. I am using this repository to show how I work with technology and how I think about building.

## Project structure

```text
.
├── README.md
├── src/
│   └── analyze_video_metrics.py
├── examples/
│   └── sample_metrics.json
└── docs/
    └── technical-approach.md
```

## Run the metric analysis example

```bash
python src/analyze_video_metrics.py examples/sample_metrics.json
```

The example calculates simple summary statistics and highlights the gap between early retention and episode completion.

## Important note

This repository is a portfolio of technical approach and reusable experiments. It does not claim that every example here is production code or that I personally wrote every underlying tool used by Brevflix.
